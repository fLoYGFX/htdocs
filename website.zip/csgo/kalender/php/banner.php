<?php


$banner = '

<!-- banner-->
<div class="w3layouts-banner-slider">
				<div class="container">
					<div class="slider">
						<div class="callbacks_container">
						
						</div>
						<div class="clearfix"> </div>

					</div>
				</div>
		</div>
	<!-- //banner -->

<!-- /banner-->



'



?>

<?php


$services='


	<div class="services">
		<div class="container">
		<div class="ser-wthree">
			<div class="services-agileinfo">
				<div class="col-sm-4 col-xs-6 services-w3grids">
					<div class="ser-agile">
						<div class="services-icon hvr-radial-in">
							<a href="csgo/maps/cache.php"><i class="fa " aria-hidden="true"><img src="images/effect.png" style="width: 80px; height: 80px; margin: -40px;"></img></i></a>
						</div>
						<h4>Kalender:</h4>
						<p>Hier findet ihr alle Matchtermine sowie Trainingszeiten!</p>
					</div>
				</div>
				<div class="col-sm-4 col-xs-6 services-w3grids">
					<div class="ser-agile">
						<div class="services-icon hvr-radial-in">
							<a href="csgo/maps/cache.php"><i class="fa" aria-hidden="true"><img src="images/effect.png" style="width: 80px; height: 80px; margin: -40px;"></img></i></a>
						</div>
						<h4>Taktikbuch</h4>
						<p>Hier findet ihr unser Taktikbuch!<br><br></p>
					</div>
				</div>
				<div class="col-sm-4 col-xs-6 services-w3grids">
					<div class="ser-agile">
						<div class="services-icon hvr-radial-in">
						<a href="csgo/maps/maps.php"><i class="fa" aria-hidden="true"><img src="images/effect.png" style="width: 80px; height: 80px; margin: -40px;"></img></i></a>
						</div>
						<h4>Maps:</h4>
						<p>Unter Maps findet ihr alle Maps mit Taktiken sowie Utility!</p>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
			</div>
		</div>
	</div>


'

?>

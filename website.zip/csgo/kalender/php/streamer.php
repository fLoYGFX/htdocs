<?php


$streamer = '


<!-- team -->
	<div class="team">
		<div class="container">
			<h3 class="agileits-title w3title1">WIR STREAMEN AUCH!</h3>
			<p class="top-p">Hier findet ihr alle unsere Streamer und ihre sozialen Netzwerke!</p>
			<div class="agile_team_grids" style="margin-left: 300px;">
				<div class="col-md-4 agile_team_grid agile1">
					<div class="agile_team_grid_main">
						<img src="images/streamer/dealer.jpg" alt=" " class="img-responsive" />
						<div class="p-mask">
							<ul class="social-icons">
								<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
								<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							</ul>
						</div>
					</div>
					<div class="agile_team_grid1">
						<h4>DeaLer</h4>
						<p>Unsere AWP!</p>
					</div>
				</div>
				<div class="col-md-4 agile_team_grid agile2">
					<div class="agile_team_grid_main">
						<img src="images/streamer/mars.jpg" alt=" " class="img-responsive" />
						<div class="p-mask">
							<ul class="social-icons">
								<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
								<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							</ul>
						</div>
					</div>

					<div class="agile_team_grid1">
						<h4>xiMars*</h4>
						<p>Einer unserer Entry Fragger!</p>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //team -->






';







?>

<?php


$banner = '

<!-- banner-->
<div class="w3layouts-banner-slider">
				<div class="container">
					<div class="slider">
						<div class="callbacks_container">
							<ul class="rslides callbacks callbacks1" id="slider4">
								<li>
									<div class="top-agileits-banner">
										<div class="agileits-banner-info">
											<h3>Team Effect</h3>
										</div>

										<div class="clearfix"> </div>
									</div>
								</li>
								<li>
									<div class="top-agileits-banner">
										<div class="agileits-banner-info">
											<h3><a href="csgo/kalender/training.php" style="color: white;">Kalender</a></h3>
										</div>

										<div class="clearfix"> </div>
									</div>
								</li>
								<li>
									<div class="top-agileits-banner">
										<div class="agileits-banner-info">
											<h3><a href="csgo/maps/maps.php" style="color: white;">Maps:</a></h3>
										</div>
										<div class="clearfix"> </div>
									</div>
								</li>
								<li>
									<div class="top-agileits-banner">
										<div class="agileits-banner-info">
											<h3><a href="csgo/kalender/training.php" style="color: white;">Taktikbuch</a></h3>
										</div>
									<div class="clearfix"> </div>
									</div>
								</li>
							</ul>
						</div>
						<div class="clearfix"> </div>

					</div>
				</div>
		</div>
	<!-- //banner -->

<!-- /banner-->



'



?>

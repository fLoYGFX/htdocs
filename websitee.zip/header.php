<?php
session_start();
if(isset($_SESSION['user'])){
  $user = $_SESSION['user'];
}

$footerk ='

        <div class="copyright">
          <p> &copy '.date("Y").' Team Effect | Design by <a href="http://w3layouts.com/" target="_blank">W3layouts</a></p>
        </div>

';


$footerMaps ='

          <div class="copyright text-center">
            <p> &copy '.date("Y").' Team Effect | Design by <a href="http://w3layouts.com/" target="_blank">W3layouts</a></p>
            </p>
          </div>


';

?>
